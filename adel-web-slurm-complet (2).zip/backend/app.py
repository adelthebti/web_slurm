from flask import Flask, request, jsonify
from flask_cors import CORS
from pymongo import MongoClient
from utils import run_command
import subprocess
import os
from datetime import datetime

app = Flask(__name__)
CORS(app)

client = MongoClient("mongodb://localhost:27017")
db = client["slurm"]
collection = db["job_submissions"]

@app.route('/api/submit', methods=['POST'])
def submit_job():
    data = request.json
    cmd = data.get('command')
    output = run_command(cmd)
    collection.insert_one({
        "submitted_at": datetime.utcnow(),
        "command": cmd,
        "output": output
    })
    return jsonify({'output': output})

# autres routes comme /api/jobs, /api/slurm-scripts, etc...
