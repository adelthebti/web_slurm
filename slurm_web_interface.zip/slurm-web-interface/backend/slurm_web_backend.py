
from flask import Flask, jsonify, request
import os
import subprocess
import tempfile
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

SLURM_DIRECTORIES = [
    "/home/adel/espritSIM",
    "/home/adel/espritIA",
    "/home/adel/slurm_jobs"
]

@app.route("/api/scripts", methods=["GET"])
def list_scripts():
    scripts = []
    for directory in SLURM_DIRECTORIES:
        if os.path.exists(directory):
            for filename in os.listdir(directory):
                if filename.endswith(".slurm"):
                    scripts.append({
                        "name": filename,
                        "path": os.path.join(directory, filename)
                    })
    return jsonify(scripts)

@app.route("/api/submit", methods=["POST"])
def submit_job():
    data = request.get_json()
    script_path = data.get("script_path")
    begin_time = data.get("begin_time")
    duration = data.get("duration")
    gpus = int(data.get("gpus", 1))
    gpu_ids = data.get("gpu_ids")

    if not os.path.exists(script_path):
        return "Erreur: Script introuvable.", 400

    try:
        with open(script_path, 'r') as f:
            original_content = f.read()

        if gpu_ids:
            export_line = f"export CUDA_VISIBLE_DEVICES={gpu_ids}\n"
            new_content = export_line + original_content
        else:
            new_content = original_content

        with tempfile.NamedTemporaryFile(delete=False, suffix=".slurm", mode='w') as tmp:
            tmp.write(new_content)
            tmp_path = tmp.name

        cmd = [
            "sudo", "sbatch",
            f"--begin={begin_time}",
            f"--time={duration}",
            f"--gres=gpu:{gpus}",
            tmp_path
        ]

        result = subprocess.check_output(cmd, stderr=subprocess.STDOUT)
        return result.decode(), 200

    except subprocess.CalledProcessError as e:
        return f"Erreur lors de la soumission :\n{e.output.decode()}", 500

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
