
import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';

export default function SlurmSubmitter() {
  const [scripts, setScripts] = useState([]);
  const [selectedScript, setSelectedScript] = useState('');
  const [beginTime, setBeginTime] = useState('');
  const [duration, setDuration] = useState('00:30:00');
  const [gpus, setGpus] = useState(1);
  const [gpuIds, setGpuIds] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetch('http://localhost:5000/api/scripts')
      .then(res => res.json())
      .then(data => setScripts(data));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch('http://localhost:5000/api/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        script_path: selectedScript,
        begin_time: beginTime,
        duration,
        gpus,
        gpu_ids: gpuIds.trim() || null
      })
    });
    const data = await res.text();
    setMessage(data);
  };

  return (
    <div className="p-10 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-center">🎛️ Interface de soumission SLURM</h1>

      <Card className="shadow-xl">
        <CardContent className="space-y-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label className="font-semibold">📄 Script SLURM</Label>
              <Select onValueChange={setSelectedScript}>
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner un script" />
                </SelectTrigger>
                <SelectContent>
                  {scripts.map(script => (
                    <SelectItem key={script.path} value={script.path}>{script.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="font-semibold">🕓 Heure de début</Label>
                <Input
                  type="text"
                  placeholder="2025-04-16T18:30:00"
                  value={beginTime}
                  onChange={e => setBeginTime(e.target.value)}
                  required
                />
              </div>

              <div>
                <Label className="font-semibold">⏱️ Durée</Label>
                <Input
                  type="text"
                  placeholder="00:30:00"
                  value={duration}
                  onChange={e => setDuration(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="font-semibold">🎮 Nombre de GPU</Label>
                <Input
                  type="number"
                  min="1"
                  max="8"
                  value={gpus}
                  onChange={e => setGpus(parseInt(e.target.value))}
                />
              </div>

              <div>
                <Label className="font-semibold">🔢 IDs GPU (optionnel)</Label>
                <Input
                  type="text"
                  placeholder="Ex: 0,1,2"
                  value={gpuIds}
                  onChange={e => setGpuIds(e.target.value)}
                />
              </div>
            </div>

            <Button type="submit" className="w-full text-lg">🚀 Soumettre le job</Button>
          </form>

          {message && (
            <div className="bg-green-100 p-4 rounded-md mt-6 text-sm text-green-800 border border-green-300">
              <pre>{message}</pre>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
