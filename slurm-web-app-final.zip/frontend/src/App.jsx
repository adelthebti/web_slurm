
import { useState, useEffect } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import FullCalendar from "@fullcalendar/react";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";

export default function SlurmGPUScheduler() {
  const [jobName, setJobName] = useState("");
  const [beginTime, setBeginTime] = useState("");
  const [duration, setDuration] = useState("04:00:00");
  const [gpuIndex, setGpuIndex] = useState("");
  const [scriptPath, setScriptPath] = useState("");
  const [gpuOptions, setGpuOptions] = useState([]);
  const [scriptMap, setScriptMap] = useState({});
  const [output, setOutput] = useState("");
  const [calendarEvents, setCalendarEvents] = useState([]);

  useEffect(() => {
    fetchSlurmScripts();
    fetchCalendarReservations();
  }, []);

  useEffect(() => {
    if (beginTime) fetchAvailableGPUs(beginTime);
  }, [beginTime]);

  const fetchSlurmScripts = async () => {
    const res = await fetch("/api/slurm-scripts");
    const data = await res.json();
    setScriptMap(data.scripts_by_dir || {});
  };

  const fetchAvailableGPUs = async (datetime) => {
    const res = await fetch(`/api/available-gpus?datetime=${datetime}`);
    const data = await res.json();
    setGpuOptions(data.available_gpus || []);
  };

  const fetchCalendarReservations = async () => {
    const res = await fetch("/api/calendar-reservations");
    const data = await res.json();
    const events = data.map(job => ({
      title: `${job.job_name} (GPU ${job.gpu})`,
      start: job.start_time,
      end: computeEndTime(job.start_time, job.duration),
      backgroundColor: "#2563eb"
    }));
    setCalendarEvents(events);
  };

  const computeEndTime = (start, duration) => {
    const [h, m, s] = duration.split(":").map(Number);
    const d = new Date(start);
    d.setHours(d.getHours() + h);
    d.setMinutes(d.getMinutes() + m);
    d.setSeconds(d.getSeconds() + s);
    return d.toISOString();
  };

  const submitJob = async () => {
    const cmd = `sudo sbatch --begin=${beginTime} --time=${duration} --gpu-bind=map_gpu:${gpuIndex} ${scriptPath}`;
    const res = await fetch("/api/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ command: cmd })
    });
    const data = await res.json();
    setOutput(data.output);
    fetchCalendarReservations();
  };

  return (
    <div className="container py-4">
      <h2 className="mb-4 fw-bold text-success">📅 Planifier un job GPU avec Slurm</h2>

      <div className="row mb-4">
        <div className="col-md-6">
          <input className="form-control mb-2" placeholder="Nom du job" value={jobName} onChange={e => setJobName(e.target.value)} />
          <input className="form-control mb-2" type="datetime-local" value={beginTime} onChange={e => setBeginTime(e.target.value + ":00")} />
          <input className="form-control mb-2" placeholder="Durée (HH:MM:SS)" value={duration} onChange={e => setDuration(e.target.value)} />

          <select className="form-select mb-2" value={gpuIndex} onChange={e => setGpuIndex(e.target.value)}>
            <option value="">-- Choisir un GPU disponible --</option>
            {gpuOptions.map((gpu, index) => (
              <option key={index} value={gpu}>GPU {gpu}</option>
            ))}
          </select>

          <select className="form-select mb-2" value={scriptPath} onChange={e => setScriptPath(e.target.value)}>
            <option value="">-- Sélectionner un script .slurm --</option>
            {Object.entries(scriptMap).map(([dir, scripts], i) => (
              <optgroup key={i} label={dir}>
                {scripts.map((file, j) => (
                  <option key={j} value={`/home/adel/${dir}/${file}`}>{file}</option>
                ))}
              </optgroup>
            ))}
          </select>

          <button className="btn btn-primary" onClick={submitJob}>🚀 Lancer le job</button>
          <textarea readOnly className="form-control mt-3" value={output} rows={3} />
        </div>
      </div>

      <h3 className="mb-3 fw-bold text-info">📆 Réservations GPU</h3>
      <FullCalendar
        plugins={[timeGridPlugin, interactionPlugin]}
        initialView="timeGridWeek"
        events={calendarEvents}
        height="auto"
      />
    </div>
  );
}
