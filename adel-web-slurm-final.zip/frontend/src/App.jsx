import React from 'react';
export default function SlurmGPUScheduler() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>✅ Interface Slurm GPU opérationnelle</h1>
      <p>Le frontend fonctionne correctement 🎉</p>
    </div>
  );
}
