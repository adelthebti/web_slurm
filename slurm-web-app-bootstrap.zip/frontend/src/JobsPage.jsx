// ✅ frontend/src/JobsPage.jsx
import React, { useEffect, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

// 🧠 Composant d'affichage de la liste des jobs Slurm
export default function JobsPage() {
  // 📦 État local pour stocker la liste des jobs
  const [jobList, setJobList] = useState([]);

  // 🚀 Appel API au chargement de la page
  useEffect(() => {
    fetchJobs();
  }, []);

  // 📥 Récupération des jobs via l'API backend
  const fetchJobs = async () => {
    try {
      const res = await fetch("/api/jobs");
      const data = await res.json();
      setJobList(data.jobs || []); // ✅ On stocke la réponse dans jobList
    } catch (error) {
      console.error("Erreur lors de la récupération des jobs:", error);
    }
  };

  // 🖼️ Affichage HTML de la liste formatée dans une table Bootstrap
  return (
    <div className="container py-4">
      <h2 className="mb-4 fw-bold text-primary">📄 Liste des jobs Slurm</h2>
      <div className="table-responsive">
        <table className="table table-dark table-striped table-bordered">
          <thead>
            <tr>
              <th>JOBID</th>
              <th>USER</th>
              <th>PARTITION</th>
              <th>NAME</th>
              <th>GPU_IDX</th>
              <th>ST</th>
              <th>NODELIST</th>
              <th>START_TIME</th>
              <th>TIME_LIMIT</th>
            </tr>
          </thead>
          <tbody>
            {jobList.map((line, index) => (
              <tr key={index}>
                {line.split(/\s+/).map((word, i) => (
                  <td key={i}>{word}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}