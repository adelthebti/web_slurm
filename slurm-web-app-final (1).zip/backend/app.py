from flask import Flask, request, jsonify
from flask_cors import CORS
from pymongo import MongoClient
from utils import run_command
import subprocess
import os
from datetime import datetime

app = Flask(__name__)
CORS(app)

client = MongoClient("mongodb://localhost:27017")
db = client["slurm"]
collection = db["job_submissions"]

@app.route('/api/submit', methods=['POST'])
def submit_job():
    data = request.json
    cmd = data.get('command')
    output = run_command(cmd)
    collection.insert_one({
        "submitted_at": datetime.utcnow(),
        "command": cmd,
        "output": output
    })
    return jsonify({'output': output})

@app.route('/api/jobs', methods=['GET'])
def list_jobs():
    cmd = "squeue -o '%.8i %.10u %.20j %.10P %.6b %.2t %.10R %.19S %.9l' -h"
    output = run_command(cmd)
    return jsonify({'jobs': output.splitlines()})

@app.route('/api/slurm-scripts', methods=['GET'])
def list_slurm_scripts():
    base = "/home/adel"
    tree = {}
    for root, _, files in os.walk(base):
        slurms = [f for f in files if f.endswith(".slurm")]
        if slurms:
            rel_dir = os.path.relpath(root, base)
            tree[rel_dir] = slurms
    return jsonify({'scripts_by_dir': tree})

@app.route('/api/available-gpus', methods=['GET'])
def get_available_gpus():
    dt = request.args.get('datetime')
    all_gpus = set(map(str, range(8)))
    reserved = set()
    res = subprocess.run(["squeue", "-o", "%.6b %.19S", "-h"], stdout=subprocess.PIPE, text=True)
    for line in res.stdout.splitlines():
        gpu_map, start = line.split()
        if "map_gpu:" in gpu_map:
            gpu_ids = gpu_map.split("map_gpu:")[1].split(",")
            start_time = datetime.strptime(start, "%Y-%m-%dT%H:%M:%S")
            req_time = datetime.strptime(dt, "%Y-%m-%dT%H:%M:%S")
            if start_time <= req_time:
                reserved.update(gpu_ids)
    return jsonify({'available_gpus': sorted(list(all_gpus - reserved))})

@app.route('/api/calendar-reservations', methods=['GET'])
def slurm_calendar():
    result = subprocess.run(
        ["squeue", "-o", "%.18i %.10u %.20j %.10P %.6b %.2t %.10R %.19S %.9l", "-h"],
        stdout=subprocess.PIPE, text=True
    )
    jobs = []
    for line in result.stdout.strip().splitlines():
        parts = line.split()
        if len(parts) >= 9:
            jobs.append({
                "job_id": parts[0],
                "user": parts[1],
                "job_name": parts[2],
                "partition": parts[3],
                "gpu": parts[4].replace("map_gpu:", ""),
                "state": parts[5],
                "node": parts[6],
                "start_time": parts[7],
                "duration": parts[8]
            })
    return jsonify(jobs)

@app.route('/api/history', methods=['GET'])
def job_history():
    docs = list(collection.find().sort("submitted_at", -1).limit(20))
    return jsonify([{
        "command": doc["command"],
        "output": doc["output"],
        "submitted_at": doc["submitted_at"].isoformat()
    } for doc in docs])